export default interface containerProps{
    children: React.ReactNode,
    className?:string
}