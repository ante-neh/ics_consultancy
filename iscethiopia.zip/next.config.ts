import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images:{
    domains:["via.placeholder.com"]
  },
  basePath:"/iscethiopia",
  trailingSlash:true,
};

export default nextConfig;
