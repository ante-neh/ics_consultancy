import About from "@/pages/aboutPage";

const AboutPage = () => {
  return (
    <About/>
  );
};

export default AboutPage;
